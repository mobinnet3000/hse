"""Knowledge base app package."""
