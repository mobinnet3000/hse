from django.apps import AppConfig


class PermitsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.permits"
    verbose_name = "مجوزهای کار و تحویل شیفت"
