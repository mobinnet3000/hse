"""AI Assistant app package."""
