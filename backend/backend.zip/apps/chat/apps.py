from django.apps import AppConfig


class ChatConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.chat"
    verbose_name = "پیام‌رسان داخلی و گفت‌وگوی تیمی HSE"
