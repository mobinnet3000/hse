"""Incidents management application."""
